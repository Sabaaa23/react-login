import React, {useState} from 'react';
import Css from './App.css';
import Login from "./components/Login";
import Registration from "./components/Registration";

function App() {

  const [currentform, setCurrentform] = useState('login');
  const toggleForm = (formName) => {
    setCurrentform(formName);
  }

  return (
    <div className="App">
      {currentform === "login" ? <Login onFormSwitch={toggleForm} /> : <Registration onFormSwitch={toggleForm} />}
    </div>
  );
}

export default App;
