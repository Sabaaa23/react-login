import React, { useState } from 'react';
import Button from './Button';
import Input from './Input';

export default function Registration(props) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [age, setAge] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [registered, setRegistered] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
  
    if (firstName && lastName && age && email && password) {
      setErrorMessage("");
      setRegistered(true);
      setEmail("");
      setPassword("");
      setAge("");
      setFirstName("");
      setLastName("");
    } else {
      setErrorMessage("All fields are required. Please fill in all the fields.");
      setTimeout(() => {
        setErrorMessage("");
      }, 2000);
    }
  };
  return (
    <div className='auth-form'>
      {registered ? (
        <div>
          <h1>Registration successful! You can now log in.</h1>
          <Button  type='submit' style={{backgroundColor: "rgb(19, 57, 248)" , color: "#ffffff" , width:"307.2px", height:"32.2px" , margin: "0.5rem 0"}} onClick={() => props.onFormSwitch('login')}>Login</Button>
        </div>
      ) : (
        <form className='registration-form' onSubmit={handleSubmit}>
          <h1 style={{ marginBottom: "30px" }}>Registration Form</h1>

          {errorMessage && (
            <div style={{ color: 'red', marginBottom: '20px' }}>{errorMessage}</div>
          )}
          <Input 
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)} 
            type='text' 
            placeholder='First Name'>
           </Input>
          <Input
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            type='text' 
            placeholder='Last Name'>
            </Input>
          <Input 
            value={age} 
            onChange={(e) => setAge(e.target.value)} 
            type='number' 
            placeholder='Age'>
          </Input>
          <Input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type='email'
            placeholder='Email'>
            </Input>
          <Input
           value={password}
            onChange={(e) => setPassword(e.target.value)}
            type='password' 
            placeholder='Password'>
            </Input>
          <Button  type='submit' style={{backgroundColor: "rgb(19, 57, 248)" , color: "#ffffff" , width:"307.2px", height:"32.2px" , margin: "0.5rem 0"}}>Register</Button>
          
        </form>
      )}

      {!registered && (
      <Button  type='submit' style={{backgroundColor: "rgb(19, 57, 248)" , color: "#ffffff" , width:"307.2px", height:"32.2px" , margin: "0.5rem 0"}} onClick={() => props.onFormSwitch('login')}>
        Already have an account? Login here
      </Button>
    )}
    </div>
  );
};