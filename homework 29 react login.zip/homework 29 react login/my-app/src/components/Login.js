import React, { useState } from 'react';
import Button  from './Button';
import Input from './Input';

export default function Login(props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e) => {
    if (email === 'user@example.com' && password === 'password123') {
      setLoggedIn(true);
      setErrorMessage('');
    } else {
      setErrorMessage('Incorrect email or password. Please try again.');
      setTimeout(() => {
        setErrorMessage('');
      }, 2000);
    }

    e.preventDefault();
    setEmail('');
    setPassword('');
  };

  const handleGoBack = () => {
    setLoggedIn(false);
    setErrorMessage('');
  };
 console.log(email)

  return (
    <div className='auth-form'>
      {loggedIn ? (
        <div>
          <h1>Successfully logged in</h1>
          <Button  type='submit' style={{backgroundColor: "rgb(19, 57, 248)" , color: "#ffffff" , width:"307.2px", height:"32.2px" , margin: "0.5rem 0"}} onClick={handleGoBack}>Go back</Button>
        </div>
      ) : (
        <form className='login-form' onSubmit={handleSubmit}>
          <h1 style={{ marginBottom: '30px' }}>Login Form</h1>

          {errorMessage && (
            <div style={{ color: 'red', marginBottom: '20px' }}>{errorMessage}</div>
          )}
          <Input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type='email'
            placeholder='Email'
          ></Input>
          <Input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type='password'
            placeholder='Password'
          ></Input>
          <Button type='submit' style={{backgroundColor: "rgb(19, 57, 248)" , color: "#ffffff" , width:"307.2px", height:"32.2px" , margin: "0.5rem 0"}}>Login</Button>
  
        </form>
      )}

      {!loggedIn && (
        <Button  type='submit' style={{backgroundColor: "rgb(19, 57, 248)" , color: "#ffffff" , width:"307.2px", height:"32.2px" , margin: "0.5rem 0"}} onClick={() => props.onFormSwitch('register')}>
          Don't have an account? Register here
        </Button>
      )}
    </div>
  );
};
