import React from 'react'

export default function Input({children,value, onChange, type, placeholder}) {
  return (
    <input
    value={value}
    onChange={onChange}
    type={type}
    placeholder={placeholder}>{children}</input>
  )
}
