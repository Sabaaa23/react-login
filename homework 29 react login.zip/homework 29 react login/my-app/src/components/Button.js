import React from 'react'

export default function Button({children, style, type, onClick}) {
  return (
    <button
     onClick={onClick}
     type={type ? type: "submit"}
     style={style ? style: {backgroundColor: "red" , color:"#ffffff" , width: "300px"}} >{children}</button>
  )
}
